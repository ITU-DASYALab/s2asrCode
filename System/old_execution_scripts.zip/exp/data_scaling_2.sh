#!/bin/bash


#SBATCH -J tr-d
#SBATCH -o ./logs/DataScaling/tr-d-%A-%a-%N.out
#SBATCH -N 1
#SBATCH -t 6:00:00
#SBATCH --array=0-14
#SBATCH -c 8
#SBATCH -p desktop
#SBATCH --gres=gpu:1
#SBATCH --mem=30000M

##
# This experiment test the scaling of data , using different features extracted from the files.
##
echo "Running on: $(hostname)"

data=("00001" "0000*"  "000*" "00[0-5]*" "*")
input_tfrecord="FE_data/EN/train${data[$SLURM_ARRAY_TASK_ID % 5]}.tfrecord"

batch_size=32
LSTM_size=960
LSTM_Layer_count=2
stride=2

if (( SLURM_ARRAY_TASK_ID <= 4 )); then
    feature_names="mfccs,log_mel_spectrograms"
    feature_sizes="13,80"
elif (( SLURM_ARRAY_TASK_ID <= 9 )); then
    feature_names="log_mel_spectrograms"
    feature_sizes="80"
else
    feature_names="mfccs"
    feature_sizes="13"
fi


if [ -z "$1" ]; then
    name=$SLURM_JOB_NAME-$SLURM_ARRAY_JOB_ID-DS-V2-$SLURM_ARRAY_TASK_ID
    echo "No Model-Name specified selecting:$name" 
else
    echo "Model name specified to : $1"
    name=$1
fi

echo $batch_size
echo $LSTM_size
echo $input_tfrecord


python3 src/AM.py \
    --num_gpu=1 \
    --stride=$stride \
    --batch_size=$batch_size \
    --LSTM_size=$LSTM_size \
    --LSTM_Layer_count=$LSTM_Layer_count \
    --input_tfrecord=$input_tfrecord \
    --feature_names=$feature_names \
    --feature_sizes=$feature_sizes \
    --dictionary="EN" \
    --training_directory="models/scaling_2/$name/" \
    --max_gpu_memory_use=0.7 \
    &

sleep 16

python3 src/AM_eval.py \
    --batch_size=4 \
    --stride=$stride \
    --input_tfrecord="FE_data/EN/train0000*.tfrecord"\
    --LSTM_size=$LSTM_size \
    --LSTM_Layer_count=$LSTM_Layer_count \
    --dictionary="EN" \
    --training_directory="models/scaling_2/$name/" \
    --summary_name="subset_data" \
    --max_gpu_memory_use=0.15 \
    &

python3 src/AM_eval.py \
    --batch_size=4 \
    --stride=$stride \
    --LSTM_size=$LSTM_size \
    --LSTM_Layer_count=$LSTM_Layer_count \
    --input_tfrecord="FE_data/EN/dev*.tfrecord" \
    --dictionary="EN" \
    --training_directory="models/scaling_2/$name/" \
    --summary_name="dev_data" \
    --max_gpu_memory_use=0.15 \
    &

wait
