#!/bin/bash

#SBATCH -J tr
#SBATCH -o ./logs/Train/Train-%J-%N.out
#SBATCH -N 1
#SBATCH -t 24:00:00
#SBATCH -c 48
#SBATCH -p gpu
#SBATCH --gres=gpu:v100:2
#SBATCH --mem=190000M

echo "Running on: $(hostname)"

if [ -z "$1" ]; then
    name=$SLURM_JOB_NAME-$SLURM_JOB_ID-Big
    echo "No Model-Name specified selecting:$name" 
else
    echo "Model name specified to : $1"
    name=$1
fi

LSTM_size=1510
LSTM_Layer_count=5
curriculum_learning=True
model="StreamSpeechM33"


python3 src/AM.py \
    --num_gpu=2 \
    --batch_size=126 \
    --LSTM_size=$LSTM_size \
    --LSTM_Layer_count=$LSTM_Layer_count \
    --input_tfrecord="FE_data/EN/train*.tfrecord" \
    --dictionary="EN" \
    --training_directory="models/$name/" \
    --buffer_size=100 \
    --num_parallel_reader=16 \
    --curriculum_learning=$curriculum_learning \
    --model=$model \
    &

sleep 16

python3 src/AM_eval.py \
    --batch_size=64 \
    --LSTM_size=$LSTM_size \
    --LSTM_Layer_count=$LSTM_Layer_count \
    --input_tfrecord="FE_data/EN/dev*.tfrecord" \
    --dictionary="EN" \
    --summary_name="dev_data" \
    --training_directory="models/$name/" \
    --curriculum_learning=False \
    --model=$model \
    &


python3 src/AM_eval.py \
    --batch_size=64 \
    --LSTM_size=$LSTM_size \
    --LSTM_Layer_count=$LSTM_Layer_count \
    --input_tfrecord="FE_data/EN/train0000*.tfrecord" \
    --dictionary="EN" \
    --training_directory="models/$name/" \
    --summary_name="subset_data" \
    --curriculum_learning=False \
    --model=$model \
    &

wait
