#/bin/bash


name="ex4"

#python3 src/FE.py \
#    --output_folder=FE_data/EN/ \
#    --dictionary=dict/EN.txt \
#    --input_dataset=data/EN/ \
#    --logging_level=60


#python3 src/AM.py \
#    --activate_learning_rate_decay=False \
#    --num_gpu=4 \
#    --batch_size=512 \
#    --training_directory="models/$name/" \
#    --input_tfrecord="FE_data/EN/train*.tfrecord" \
#    --dictionary="dict/EN.txt" \
#    &> graphs/ex3.out &

python3 src/AM.py \
    --activate_learning_rate_decay=False \
    --num_gpu=4 \
    --batch_size=512 \
    --training_directory="models/$name/" \
    --input_tfrecord="FE_data/EN/train*.tfrecord" \
    --dictionary="EN" \
    --new_model=False \
    &> graphs/ex3.out &


sleep 600

python3 src/AM_eval.py \
    --training_directory="models/$name/" \
    --input_tfrecord="FE_data/EN/dev*.tfrecord" \
    --dictionary="EN" \
    &> graphs/ex3_eval.out &
    
python3 src/AM_eval.py \
    --training_directory="models/$name/" \
    --input_tfrecord="FE_data/EN/train*.tfrecord" \
    --dictionary="EN" \
    --summary_name="train_eval" \
    --batch_size=256 \
    &> graphs/ex3_train_eval.out &
    
wait