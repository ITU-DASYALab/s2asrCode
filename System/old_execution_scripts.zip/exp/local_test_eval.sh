#/bin/bash


model="LogisticModel"

if [[ $1 = "1" ]]; then
    custom_beam_search=True
else
    custom_beam_search=false
fi

python3 src/AM_eval.py \
    --batch_size=16 \
    --num_gpu=0 \
    --LSTM_size=256 \
    --conv_output=512 \
    --conv_width=11 \
    --max_frames=1000 \
    --LSTM_Layer_count=1 \
    --model=$model \
    --curriculum_learning=False \
    --beam_width=$2 \
    --input_tfrecord="FE_data/LibriSpeech/train00001.tfrecord" \
    --dictionary="EN_chars" \
    --include_unknown=False \
    --summary_name="eval" \
    --custom_beam_search=$custom_beam_search \
    #--wait_for_checkpoint=False \

