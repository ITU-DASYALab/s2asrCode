#!/bin/bash

#SBATCH -J MFCCVSLogMel
#SBATCH -o ./logs/MFCCVSLogMel-%A-%a-%N.out
#SBATCH -N 1
#SBATCH -t 24:00:00
#SBATCH --array=0-2
#SBATCH -c 8
#SBATCH -p desktop
#SBATCH --gres=gpu:1
#SBATCH --mem=30000M

echo "Running on: $(hostname)"

if [ -z "$1" ]; then
    name=$SLURM_JOB_NAME-$SLURM_ARRAY_JOB_ID-$SLURM_ARRAY_TASK_ID
    echo "No Model-Name specified selecting:$name" 
else
    echo "Model name specified to : $1"
    name=$1
fi


feature_names=("mfccs" "log_mel_spectrograms" "mfccs,log_mel_spectrograms")
feature_sizes=("13" "80" "13,80")

model="StreamSpeechM33"

LSTM_size=512
LSTM_Layer_count=2
feature_names=${feature_names[$SLURM_ARRAY_TASK_ID]}
feature_sizes=${feature_sizes[$SLURM_ARRAY_TASK_ID]}


training_directory="models/MFCCVSLogMel/$name/"

python3 src/AM.py \
    --num_gpu=1 \
    --batch_size=32 \
    --LSTM_size=$LSTM_size \
    --LSTM_Layer_count=$LSTM_Layer_count \
    --input_tfrecord="FE_data/EN/train*.tfrecord" \
    --dictionary="EN" \
    --training_directory=$training_directory \
    --model=$model \
    --max_gpu_memory_use=0.6 \
    --feature_names=$feature_names \
    --feature_sizes=$feature_sizes \
    &

sleep 16

python3 src/AM_eval.py \
    --batch_size=4 \
    --LSTM_size=$LSTM_size \
    --LSTM_Layer_count=$LSTM_Layer_count \
    --input_tfrecord="FE_data/EN/dev*.tfrecord" \
    --dictionary="EN" \
    --summary_name="dev_data" \
    --training_directory=$training_directory \
    --curriculum_learning=False \
    --model=$model \
    --max_gpu_memory_use=0.2 \
    &


python3 src/AM_eval.py \
    --batch_size=4 \
    --LSTM_size=$LSTM_size \
    --LSTM_Layer_count=$LSTM_Layer_count \
    --input_tfrecord="FE_data/EN/train0000*.tfrecord" \
    --dictionary="EN" \
    --summary_name="subset_data" \
    --training_directory=$training_directory \
    --curriculum_learning=False \
    --model=$model \
    --max_gpu_memory_use=0.2 \
    &

wait
