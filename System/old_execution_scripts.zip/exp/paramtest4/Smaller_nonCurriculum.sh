#!/bin/bash

#SBATCH -J Smaller-NonCurriculum
#SBATCH -o ./logs/Smaller-NoneCurriculum-%J-%N.out
#SBATCH -N 1
#SBATCH -t 24:00:00
#SBATCH -c 48
#SBATCH -p gpu
#SBATCH --gres=gpu:v100:2
#SBATCH --mem=190000M

echo "Running on: $(hostname)"

if [ -z "$1" ]; then
    name=$SLURM_JOB_NAME-$SLURM_JOB_ID
    echo "No Model-Name specified selecting:$name" 
else
    echo "Model name specified to : $1"
    name=$1
fi


model="StreamSpeechM33"

training_directory="models/Smaller_nonCurriculum/$name/"

LSTM_size=512
LSTM_Layer_count=2
conv_output=800
conv_width=5

python3 src/AM.py \
    --num_gpu=2 \
    --batch_size=512 \
    --input_tfrecord="FE_data/New/EN/train*.tfrecord" \
    --dictionary="EN" \
    --training_directory=$training_directory \
    --buffer_size=100 \
    --num_parallel_reader=16 \
    --curriculum_learning=False \
    --model=$model \
    --LSTM_size=$LSTM_size \
    --LSTM_Layer_count=$LSTM_Layer_count \
    --conv_output=$conv_output \
    --conv_width=$conv_width \
    &

sleep 16

python3 src/AM_eval.py \
    --batch_size=64 \
    --input_tfrecord="FE_data/New/EN/dev*.tfrecord" \
    --dictionary="EN" \
    --training_directory=$training_directory \
    --summary_name="dev_data" \
    --curriculum_learning=False \
    --model=$model \
    --LSTM_size=$LSTM_size \
    --LSTM_Layer_count=$LSTM_Layer_count \
    --conv_output=$conv_output \
    --conv_width=$conv_width \
    &


python3 src/AM_eval.py \
    --batch_size=64 \
    --input_tfrecord="FE_data/New/EN/train0000*.tfrecord" \
    --dictionary="EN" \
    --training_directory=$training_directory \
    --summary_name="subset_data" \
    --curriculum_learning=False \
    --model=$model \
    --LSTM_size=$LSTM_size \
    --LSTM_Layer_count=$LSTM_Layer_count \
    --conv_output=$conv_output \
    --conv_width=$conv_width \
    &

wait
