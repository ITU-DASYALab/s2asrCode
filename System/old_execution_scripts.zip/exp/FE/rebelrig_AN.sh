#!/bin/bash

dictionary="EN"
output_folder="FE_data/EN/FE_Normal/"
input_dataset="data/EN/"
data_sets="dev"

echo $output_folder 
echo $input_dataset 
echo $dictionary
echo $data_sets


python3 src/FE.py \
    --output_folder=$output_folder \
    --input_dataset=$input_dataset \
    --dictionary=$dictionary \
    --data_sets=$data_sets \
    --amplitude_normalization="True" \


dictionary="EN"
output_folder="FE_data/EN/FE_Normal/"
input_dataset="data/EN/"
data_sets="test"

echo $output_folder 
echo $input_dataset 
echo $dictionary
echo $data_sets


python3 src/FE.py \
    --output_folder=$output_folder \
    --input_dataset=$input_dataset \
    --dictionary=$dictionary \
    --data_sets=$data_sets \
    --amplitude_normalization="True" \

dictionary="EN"
output_folder="FE_data/EN/FE_Normal/"
input_dataset="data/EN/"
data_sets="train"

echo $output_folder 
echo $input_dataset 
echo $dictionary
echo $data_sets


python3 src/FE.py \
    --output_folder=$output_folder \
    --input_dataset=$input_dataset \
    --dictionary=$dictionary \
    --data_sets=$data_sets \
    --amplitude_normalization="True" \


dictionary="SE"
output_folder="FE_data/sv-SE/FE_Normal/"
input_dataset="data/sv-SE/"
data_sets="dev"

echo $output_folder 
echo $input_dataset 
echo $dictionary
echo $data_sets


python3 src/FE.py \
    --output_folder=$output_folder \
    --input_dataset=$input_dataset \
    --dictionary=$dictionary \
    --data_sets=$data_sets \
    --amplitude_normalization="True" \

dictionary="SE"
output_folder="FE_data/sv-SE/FE_Normal/"
input_dataset="data/sv-SE/"
data_sets="test"

echo $output_folder 
echo $input_dataset 
echo $dictionary
echo $data_sets


python3 src/FE.py \
    --output_folder=$output_folder \
    --input_dataset=$input_dataset \
    --dictionary=$dictionary \
    --data_sets=$data_sets \
    --amplitude_normalization="True" \

dictionary="SE"
output_folder="FE_data/sv-SE/FE_Normal/"
input_dataset="data/sv-SE/"
data_sets="train"

echo $output_folder 
echo $input_dataset 
echo $dictionary
echo $data_sets


python3 src/FE.py \
    --output_folder=$output_folder \
    --input_dataset=$input_dataset \
    --dictionary=$dictionary \
    --data_sets=$data_sets \
    --amplitude_normalization="True" \
