#!/bin/bash

dictionary="EN_chars"
output_folder="FE_data/EN/FE_Chars/"
input_dataset="data/EN/"


python3 src/FE.py \
    --output_folder=$output_folder \
    --input_dataset=$input_dataset \
    --dictionary=$dictionary \
    --amplitude_normalization="False" \
    --include_unknown="False" \


