#!/bin/bash

#SBATCH -J FE_Norm
#SBATCH -o ./logs/FE/FE-Normal-%A-%a-%N.out
#SBATCH --array=0-3
#SBATCH -N 1
#SBATCH -t 04:00:00
#SBATCH -c 32
#SBATCH --mem=90000M

##SBATCH -w cn1            

echo "Running on: $(hostname)"
echo $SLURM_ARRAY_TASK_ID


output=("EN" "EN" "EN" "sv-SE" "sv-SE" "sv-SE")
output_folder="FE_data/${output[$SLURM_ARRAY_TASK_ID]}/FE_Normal/"
input_dataset="data/${output[$SLURM_ARRAY_TASK_ID]}/"

dict=("EN" "EN" "EN" "SE" "SE" "SE")
dictionary="${dict[$SLURM_ARRAY_TASK_ID]}"

data=("dev" "test" "train" "dev" "test" "train")
data_sets="${data[$SLURM_ARRAY_TASK_ID]}"

echo $output_folder 
echo $input_dataset 
echo $dictionary
echo $data_sets


python3 src/FE.py \
    --output_folder=$output_folder \
    --input_dataset=$input_dataset \
    --dictionary=$dictionary \
    --data_sets=$data_sets \
    --amplitude_normalization="False" \

