#!/bin/bash


#SBATCH -J tr-d
#SBATCH -o ./logs/Train-desk/Train-%J-%N.out
#SBATCH -N 1
#SBATCH -t 03:00:00
#SBATCH -c 8
#SBATCH -p desktop
#SBATCH --gres=gpu:1
#SBATCH --mem=30000M


echo "Running on: $(hostname)"

if [ -z "$1" ]; then
    name=$SLURM_JOB_NAME-$SLURM_JOB_ID-test
    echo "No Model-Name specified selecting:$name" 
else
    echo "Model name specified to : $1"
    name=$1
fi

python3 src/AM.py \
    --num_gpu=1 \
    --batch_size=32 \
    --input_tfrecord="FE_data/EN/train00001.tfrecord" \
    --dictionary="EN" \
    --training_directory="models/$name/" \
    &

sleep 16

python3 src/AM_eval.py \
    --batch_size=32 \
    --input_tfrecord="FE_data/EN/train00001.tfrecord" \
    --dictionary="EN" \
    --training_directory="models/$name/" \
    --summary_name="same_data" \
    &

wait
