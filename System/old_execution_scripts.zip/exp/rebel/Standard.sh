#!/bin/bash

name=$1
model="StreamSpeechM33"
training_directory="models/Standard/$name/"
FE_folder="No_amplitude_normalization"

input_tfrecord="FE_data/EN/$FE_folder/train*.tfrecord"
input_tfrecord_eval1="FE_data/EN/$FE_folder/train0000*.tfrecord"
input_tfrecord_eval2="FE_data/EN/$FE_folder/dev*.tfrecord"


conv_width=5

python3 src/AM.py \
    --num_gpu=4 \
    --batch_size=64 \
    --input_tfrecord=$input_tfrecord \
    --dictionary="EN" \
    --training_directory=$training_directory \
    --buffer_size=100 \
    --curriculum_learning=False \
    --num_parallel_reader=16 \
    --model=$model \
    --conv_width=$conv_width \
    &

sleep 16
    
python3 src/AM_eval.py \
    --batch_size=8 \
    --input_tfrecord=$input_tfrecord_eval2 \
    --dictionary="EN" \
    --training_directory=$training_directory \
    --summary_name="dev_data" \
    --curriculum_learning=False \
    --model=$model \
    --conv_width=$conv_width \
    &

wait
