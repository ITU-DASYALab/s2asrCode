#!/bin/bash

#SBATCH -J tr
#SBATCH -o ./logs/Train/Train-%J-%N.out
#SBATCH -N 1
#SBATCH -t 24:00:00
#SBATCH -c 48
#SBATCH --gres=gpu:v100:2
#SBATCH --mem=190000M



echo "Running on: $(hostname)"

if [ -z "$1" ]; then
    name=$SLURM_JOB_NAME-$SLURM_JOB_ID
    echo "No Model-Name specified selecting:$name" 
else
    echo "Model name specified to : $1"
    name=$1
fi

python3 src/AM.py \
    --num_gpu=2 \
    --batch_size=512 \
    --save_model_interval=30 \
    --training_directory="models/$name/" \
    &

sleep 120

python3 src/AM_eval.py \
    --batch_size=128 \
    --training_directory="models/$name/" \
    &

wait
