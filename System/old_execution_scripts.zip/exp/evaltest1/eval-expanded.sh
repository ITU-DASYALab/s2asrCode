#!/bin/bash

#SBATCH -J eval
#SBATCH -o ./logs/eval-%J-%N.out
#SBATCH -N 1
#SBATCH -t 4:00:00
#SBATCH -c 48
#SBATCH -p gpu
#SBATCH --gres=gpu:v100:2
#SBATCH --mem=190000M


echo "Running on: $(hostname)"

batch_size=256
eval_batch_size=128
LSTM_size=800
LSTM_Layer_count=5
conv_output=600
conv_width=11
max_frames=1200
dropout=0.05


input_tfrecord="FE_data/LibriSpeech/train*.tfrecord"
input_tfrecord_eval="FE_data/LibriSpeech/dev*.tfrecord"

dictionary="EN_chars"

model="StreamSpeechM33"

activation_function="relu"
num_epochs=3

name="costum_beam_vs_small-220-epocs3-small"
training_directory="models/$name/"

#~/StreamSpeechV2/System/models/costum_beam_vs_small-220-epocs3-small/dev-wordCTC-big

params="--LSTM_size=$LSTM_size \
    --LSTM_Layer_count=$LSTM_Layer_count \
    --conv_output=$conv_output \
    --conv_width=$conv_width \
    --dictionary=$dictionary \
    --curriculum_learning=False \
    --include_unknown=False \
    --max_frames=$max_frames \
    --model=$model \
    --activation_function=$activation_function "

#for beam_width in 32 64 128 255 512 1024
for beam_width in 2048 4096 8192 16384
do

python3 src/AM_eval.py \
    --training_directory=$training_directory \
    --input_tfrecord=$input_tfrecord_eval \
    --summary_name="after-beam-$beam_width" \
    --wait_for_checkpoint=False \
    --num_gpu=1 \
    --batch_size=$eval_batch_size \
    --custom_beam_search=True \
    --beam_width=$beam_width \
    $params \

done