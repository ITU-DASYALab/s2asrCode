#!/bin/bash

#SBATCH -J tr-d
#SBATCH -o ./logs/Train-desk/Train-%J-%N.out
#SBATCH -N 1
#SBATCH -t 00:30:00
#SBATCH -c 8
#SBATCH -p desktop
#SBATCH --gres=gpu:1
#SBATCH --mem=30000M



echo "Running on: $(hostname)"

if [ -z "$1" ]; then
    name=$SLURM_JOB_NAME-$SLURM_JOB_ID
    echo "No Model-Name specified selecting:$name" 
else
    echo "Model name specified to : $1"
    name=$1
fi

python3 src/AM.py \
    --activate_learning_rate_decay=False \
    --num_gpu=1 \
    --batch_size=64 \
    --max_frames=800 \
    --save_model_interval=30 \
    --training_directory="models/$name/" \
    --input_tfrecord="FE_data/EN/train00001.tfrecord" \
    --dictionary="dict/EN.txt" \
    --regularization_penalty=0.0 \
    --add_batch_norm=False \
    &

sleep 300

python3 src/AM_eval.py \
    --training_directory="models/$name/" \
    --input_tfrecord="FE_data/EN/train00001.tfrecord" \
    --dictionary="dict/EN.txt" \
    --summary_name="train_eval_b5" \
    --batch_size=64 \
    --beam_width=5 \
    --max_frames=800 \
    --add_batch_norm=False \
    &

python3 src/AM_eval.py \
    --training_directory="models/$name/" \
    --input_tfrecord="FE_data/EN/train00001.tfrecord" \
    --dictionary="dict/EN.txt" \
    --summary_name="train_eval_b20" \
    --batch_size=64 \
    --beam_width=20 \
    --max_frames=800 \
    --add_batch_norm=False \
    &

python3 src/AM_eval.py \
    --training_directory="models/$name/" \
    --input_tfrecord="FE_data/EN/train00001.tfrecord" \
    --dictionary="dict/EN.txt" \
    --summary_name="train_eval_b1" \
    --batch_size=64 \
    --beam_width=1 \
    --max_frames=800 \
    --add_batch_norm=False \
    &

wait
