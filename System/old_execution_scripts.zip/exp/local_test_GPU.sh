#/bin/bash


python3 src/AM.py \
    --word_based=False \
    --batch_size=512 \
    --num_gpu=2 \
    --LSTM_size=80 \
    --conv_output=256 \
    --max_frames=500 \
    --LSTM_Layer_count=2 \
    --model=LogisticModel \
