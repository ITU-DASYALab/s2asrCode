#!/bin/bash

#SBATCH -J L2Norm
#SBATCH -o ./logs/L2NormTest-%A-%a-%N.out
#SBATCH -N 1
#SBATCH -t 24:00:00
#SBATCH --array=0-9
#SBATCH -c 8
#SBATCH -p desktop
#SBATCH --gres=gpu:1
#SBATCH --mem=30000M

echo "Running on: $(hostname)"

if [ -z "$1" ]; then
    name=$SLURM_JOB_NAME-$SLURM_ARRAY_JOB_ID-L2Norm-$SLURM_ARRAY_TASK_ID
    echo "No Model-Name specified selecting:$name" 
else
    echo "Model name specified to : $1"
    name=$1
fi



l2Norm_List=(1 0)

LSTM_size_List=(32 32 128 128 256 256 512 512 960 960)


model="StreamSpeechM33"

l2Norm=${l2Norm_List[$SLURM_ARRAY_TASK_ID % 2]}

LSTM_size=${LSTM_size_List[$SLURM_ARRAY_TASK_ID]}
LSTM_Layer_count=2



training_directory="models/L2Norm/$name/"


python3 src/AM.py \
    --num_gpu=1 \
    --batch_size=32 \
    --LSTM_size=$LSTM_size \
    --LSTM_Layer_count=$LSTM_Layer_count \
    --input_tfrecord="FE_data/EN/train*.tfrecord" \
    --dictionary="EN" \
    --training_directory=$training_directory \
    --curriculum_learning=False \
    --model=$model \
    --max_gpu_memory_use=0.6 \
    --l2_batch_normalization=$l2Norm \
    --regularization_penalty=0.0 \
    &

sleep 16

python3 src/AM_eval.py \
    --batch_size=4 \
    --LSTM_size=$LSTM_size \
    --LSTM_Layer_count=$LSTM_Layer_count \
    --input_tfrecord="FE_data/EN/dev*.tfrecord" \
    --dictionary="EN" \
    --summary_name="dev_data" \
    --training_directory=$training_directory \
    --curriculum_learning=False \
    --model=$model \
    --max_gpu_memory_use=0.2 \
    --l2_batch_normalization=$l2Norm \
    &


python3 src/AM_eval.py \
    --batch_size=4 \
    --LSTM_size=$LSTM_size \
    --LSTM_Layer_count=$LSTM_Layer_count \
    --input_tfrecord="FE_data/EN/train0000*.tfrecord" \
    --dictionary="EN" \
    --summary_name="subset_data" \
    --training_directory=$training_directory \
    --curriculum_learning=False \
    --model=$model \
    --max_gpu_memory_use=0.2 \
    --l2_batch_normalization=$l2Norm \
    &

wait
