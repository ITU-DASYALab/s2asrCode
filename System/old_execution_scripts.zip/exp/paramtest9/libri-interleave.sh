#!/bin/bash

#SBATCH -J libri-inter
#SBATCH -o ./logs/interleave-array-%A-%a-%N.out
#SBATCH -N 1
#SBATCH --array=0-19%1
#SBATCH -t 4:00:00
#SBATCH -c 48
#SBATCH -p gpu
#SBATCH --gres=gpu:v100:2
#SBATCH --mem=190000M


echo "Running on: $(hostname)"

batch_size=256
eval_batch_size=128
LSTM_size=1510
LSTM_Layer_count=5
conv_output=1280
conv_width=11
max_frames=800

input_tfrecord="FE_data/LibriSpeech/train*.tfrecord"
input_tfrecord_eval2="FE_data/LibriSpeech/dev*.tfrecord"

dictionary="EN_chars"

model="StreamSpeechM33"

if [[ -z "$1" ]]; then
    num_epochs=1
else
    num_epochs=$1
fi

if (( SLURM_ARRAY_TASK_ID > 0 )); then
    new_model=False
else
    new_model=True
fi

name=$SLURM_JOB_NAME-$SLURM_ARRAY_JOB_ID-epocs$num_epochs
training_directory="models/interleave/$name/"


params="--LSTM_size=$LSTM_size \
    --LSTM_Layer_count=$LSTM_Layer_count \
    --conv_output=$conv_output \
    --conv_width=$conv_width \
    --dictionary=$dictionary \
    --curriculum_learning=False \
    --include_unknown=False \
    --max_frames=$max_frames \
    --model=$model "


while true; do 


python3 src/AM.py \
    --training_directory=$training_directory \
    --input_tfrecord=$input_tfrecord \
    --buffer_size=100 \
    --num_epochs=$num_epochs \
    --new_model=$new_model \
    --num_gpu=2 \
    --batch_size=$batch_size \
    $params \

python3 src/AM_eval.py \
    --training_directory=$training_directory \
    --input_tfrecord=$input_tfrecord_eval2 \
    --summary_name="dev" \
    --wait_for_checkpoint=False \
    --num_gpu=1 \
    --batch_size=$eval_batch_size \
    $params \

new_model=False

done
