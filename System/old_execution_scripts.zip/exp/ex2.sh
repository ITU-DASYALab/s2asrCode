#/bin/bash
# Try training without a decaying learning rate.
python3 src/AM.py --activate_learning_rate_decay=False --num_gpu=4 --batch_size=1024 --training_directory="models/ex2/"