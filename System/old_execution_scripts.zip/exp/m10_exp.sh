#!/bin/bash

#SBATCH -J tr
#SBATCH -o ./logs/Train/Train-%J-%N.out
#SBATCH -N 1
#SBATCH -t 24:00:00
#SBATCH -c 32
#SBATCH -p gpu
#SBATCH --gres=gpu:m10:8
#SBATCH --mem=200000M


echo "Running on: $(hostname)"

if [ -z "$1" ]; then
    name=$SLURM_JOB_NAME-$SLURM_JOB_ID-M10
    echo "No Model-Name specified selecting:$name" 
else
    echo "Model name specified to : $1"
    name=$1
fi

LSTM_size=1510

python3 src/AM.py \
    --num_gpu=8 \
    --batch_size=80 \
    --LSTM_size=$LSTM_size \
    --input_tfrecord="FE_data/EN/train*.tfrecord" \
    --dictionary="EN" \
    --training_directory="models/$name/" \
    &

sleep 16

python3 src/AM_eval.py \
    --batch_size=16 \
    --input_tfrecord="FE_data/EN/dev*.tfrecord" \
    --dictionary="EN" \
    --LSTM_size=$LSTM_size \
    --training_directory="models/$name/" \
    --summary_name="dev_data" \
    &


python3 src/AM_eval.py \
    --batch_size=16 \
    --input_tfrecord="FE_data/EN/train0000*.tfrecord" \
    --dictionary="EN" \
    --LSTM_size=$LSTM_size \
    --training_directory="models/$name/" \
    --summary_name="subset_data" \
    &

wait
