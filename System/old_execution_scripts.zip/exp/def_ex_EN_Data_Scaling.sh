#!/bin/bash


#SBATCH -J tr-d
#SBATCH -o ./logs/Train-desk/Train-%A-%a-%N.out
#SBATCH -N 1
#SBATCH -t 3:00:00
#SBATCH --array=10-49
#SBATCH -c 8
#SBATCH -p desktop
#SBATCH --gres=gpu:1
#SBATCH --mem=30000M


echo "Running on: $(hostname)"

data=("00001" "0000[0-2]" "0000[0-4]" "0000[0-8]" "0000*" "000[0-5]*"  "000*" "00[0-2]*" "00[0-5]*" "*")

if (( SLURM_ARRAY_TASK_ID <= 9 )); then
    input_tfrecord="FE_data/EN/train${data[$SLURM_ARRAY_TASK_ID]}.tfrecord"
    batch_size=32
    LSTM_size=1024
    LSTM_Layer_count=2
    stride=4
elif (( SLURM_ARRAY_TASK_ID <= 19 )); then
    input_tfrecord="FE_data/EN/train${data[$SLURM_ARRAY_TASK_ID - 9]}.tfrecord"
    batch_size=32
    LSTM_size=1024
    LSTM_Layer_count=2
    stride=5
elif (( SLURM_ARRAY_TASK_ID <= 29 )); then
    input_tfrecord="FE_data/EN/train${data[$SLURM_ARRAY_TASK_ID - 19]}.tfrecord"
    batch_size=32
    LSTM_size=1024
    LSTM_Layer_count=2
    stride=6
elif (( SLURM_ARRAY_TASK_ID <= 39 )); then
    input_tfrecord="FE_data/EN/train${data[$SLURM_ARRAY_TASK_ID - 29]}.tfrecord"
    batch_size=32
    LSTM_size=1024
    LSTM_Layer_count=2
    stride=7
else
    input_tfrecord="FE_data/EN/train${data[$SLURM_ARRAY_TASK_ID - 39]}.tfrecord"
    batch_size=32
    LSTM_size=1024
    LSTM_Layer_count=2
    stride=8
fi

if [ -z "$1" ]; then
    name=$SLURM_JOB_NAME-$SLURM_ARRAY_JOB_ID-DS-$SLURM_ARRAY_TASK_ID
    echo "No Model-Name specified selecting:$name" 
else
    echo "Model name specified to : $1"
    name=$1
fi

echo $batch_size
echo $LSTM_size
echo $input_tfrecord



python3 src/AM.py \
    --num_gpu=1 \
    --stride=$stride \
    --batch_size=$batch_size \
    --LSTM_size=$LSTM_size \
    --LSTM_Layer_count=$LSTM_Layer_count \
    --input_tfrecord=$input_tfrecord \
    --dictionary="EN" \
    --training_directory="models/scaling/$name/" \
    --max_gpu_memory_use=0.6 \
    &

sleep 16

python3 src/AM_eval.py \
    --batch_size=8 \
    --stride=$stride \
    --input_tfrecord=$input_tfrecord \
    --LSTM_size=$LSTM_size \
    --LSTM_Layer_count=$LSTM_Layer_count \
    --dictionary="EN" \
    --training_directory="models/scaling/$name/" \
    --summary_name="same_data" \
    --max_gpu_memory_use=0.2 \
    &

python3 src/AM_eval.py \
    --batch_size=8 \
    --stride=$stride \
    --LSTM_size=$LSTM_size \
    --LSTM_Layer_count=$LSTM_Layer_count \
    --input_tfrecord="FE_data/EN/dev*.tfrecord" \
    --dictionary="EN" \
    --training_directory="models/scaling/$name/" \
    --summary_name="dev_data" \
    --max_gpu_memory_use=0.2 \
    &

wait
