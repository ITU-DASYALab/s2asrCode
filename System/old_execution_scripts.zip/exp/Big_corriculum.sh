#!/bin/bash

#SBATCH -J corriculum
#SBATCH -o ./logs/Train/Train-%J-%A-%a-%N.out
#SBATCH -N 1
#SBATCH -t 24:00:00
#SBATCH --array=3
#SBATCH -c 48
#SBATCH -p gpu
#SBATCH --gres=gpu:v100:2
#SBATCH --mem=190000M

echo "Running on: $(hostname)"

if [ -z "$1" ]; then
    name=$SLURM_JOB_NAME-$SLURM_ARRAY_JOB_ID-Corriculum-$SLURM_ARRAY_TASK_ID
    echo "No Model-Name specified selecting:$name" 
else
    echo "Model name specified to : $1"
    name=$1
fi


frame_increase_speed_list=(0.01 0.000001 0.001 0.001)
corriculum_learning_list=(1 1 0 0)
cudnn_lstm_list=(1 1 1 0)


LSTM_size=960
LSTM_Layer_count=5
curriculum_learning=${corriculum_learning_list[$SLURM_ARRAY_TASK_ID]}
model="StreamSpeechM33"
frame_increase_speed=${frame_increase_speed_list[$SLURM_ARRAY_TASK_ID]}
cudnn_lstm=${cudnn_lstm_list[$SLURM_ARRAY_TASK_ID]}

python3 src/AM.py \
    --num_gpu=2 \
    --batch_size=126 \
    --LSTM_size=$LSTM_size \
    --LSTM_Layer_count=$LSTM_Layer_count \
    --input_tfrecord="FE_data/EN/train*.tfrecord" \
    --dictionary="EN" \
    --training_directory="models/$name/" \
    --buffer_size=100 \
    --num_parallel_reader=16 \
    --curriculum_learning=$curriculum_learning \
    --frame_increase_speed=$frame_increase_speed \
    --model=$model \
    --cudnn_lstm=$cudnn_lstm \
    &

sleep 16

python3 src/AM_eval.py \
    --batch_size=64 \
    --LSTM_size=$LSTM_size \
    --LSTM_Layer_count=$LSTM_Layer_count \
    --input_tfrecord="FE_data/EN/dev*.tfrecord" \
    --dictionary="EN" \
    --summary_name="dev_data" \
    --training_directory="models/$name/" \
    --curriculum_learning=False \
    --model=$model \
    --logging_level=50 \
    --cudnn_lstm=$cudnn_lstm \
    &


python3 src/AM_eval.py \
    --batch_size=64 \
    --LSTM_size=$LSTM_size \
    --LSTM_Layer_count=$LSTM_Layer_count \
    --input_tfrecord="FE_data/EN/train0000*.tfrecord" \
    --dictionary="EN" \
    --training_directory="models/$name/" \
    --summary_name="subset_data" \
    --curriculum_learning=False \
    --model=$model \
    --logging_level=50 \
    --cudnn_lstm=$cudnn_lstm \
    &

wait
