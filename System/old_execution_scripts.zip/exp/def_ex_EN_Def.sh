#!/bin/bash

#SBATCH -J tr-def
#SBATCH -o ./logs/Train/Train-%J-%N.out
#SBATCH -N 1
#SBATCH -t 24:00:00
#SBATCH -c 48
#SBATCH -p gpu
#SBATCH --gres=gpu:v100:2
#SBATCH --mem=190000M



echo "Running on: $(hostname)"

if [ -z "$1" ]; then
    name=$SLURM_JOB_NAME-$SLURM_JOB_ID-Def
    echo "No Model-Name specified selecting:$name" 
else
    echo "Model name specified to : $1"
    name=$1
fi


python3 src/AM.py \
    --num_gpu=2 \
    --batch_size=200 \
    --input_tfrecord="FE_data/EN/train*.tfrecord" \
    --dictionary="EN" \
    --training_directory="models/$name/" \
    &

sleep 16

python3 src/AM_eval.py \
    --batch_size=32 \
    --input_tfrecord="FE_data/EN/dev*.tfrecord" \
    --dictionary="EN" \
    --training_directory="models/$name/" \
    --summary_name="dev_data" \
    &


python3 src/AM_eval.py \
    --batch_size=8 \
    --input_tfrecord="FE_data/EN/train0000*.tfrecord" \
    --dictionary="EN" \
    --training_directory="models/$name/" \
    --summary_name="subset_data" \
    &

wait
