#!/bin/bash

#SBATCH -J data_scaling_v2
#SBATCH -o ./logs/DataScaling/data_scaling_v2-%A-%a-%N.out
#SBATCH -N 1
#SBATCH -t 24:00:00
#SBATCH --array=0-19
#SBATCH -c 8
#SBATCH -p desktop
#SBATCH --gres=gpu:1
#SBATCH --mem=30000M


echo "Running on: $(hostname)"

data=("0000*" "000[0-5]*" "000*" "00[0-5]*" "*")

batch_size=80
LSTM_size=512
LSTM_Layer_count=2
conv_output=800
conv_width=5

if (( SLURM_ARRAY_TASK_ID % 10 < 5 )); then
    FE_folder="Amplitude_normalization"
else
    FE_folder="No_amplitude_normalization"
fi

if (( SLURM_ARRAY_TASK_ID < 10 )); then
    curriculum_learning="True"
else
    curriculum_learning="False"
fi

input_tfrecord="FE_data/EN/$FE_folder/train${data[$SLURM_ARRAY_TASK_ID % 5]}.tfrecord"
input_tfrecord_eval1="FE_data/EN/$FE_folder/train0000*.tfrecord"
input_tfrecord_eval2="FE_data/EN/$FE_folder/dev*.tfrecord"


name=$SLURM_JOB_NAME-$SLURM_ARRAY_JOB_ID-$SLURM_ARRAY_TASK_ID



training_directory="models/data_scaling_v2/$name/"



python3 src/AM.py \
    --num_gpu=1 \
    --batch_size=$batch_size \
    --LSTM_size=$LSTM_size \
    --LSTM_Layer_count=$LSTM_Layer_count \
    --conv_output=$conv_output \
    --conv_width=$conv_width \
    --input_tfrecord=$input_tfrecord \
    --dictionary="EN" \
    --curriculum_learning=$curriculum_learning \
    --training_directory=$training_directory \
    --max_gpu_memory_use=0.6 \
    --buffer_size=100 \
    &

sleep 16

python3 src/AM_eval.py \
    --batch_size=4 \
    --input_tfrecord=$input_tfrecord_eval1\
    --LSTM_size=$LSTM_size \
    --LSTM_Layer_count=$LSTM_Layer_count \
    --conv_output=$conv_output \
    --conv_width=$conv_width \
    --dictionary="EN" \
    --training_directory=$training_directory \
    --curriculum_learning=False \
    --summary_name="subset" \
    --max_gpu_memory_use=0.2 \
    &

python3 src/AM_eval.py \
    --batch_size=4 \
    --input_tfrecord=$input_tfrecord_eval2 \
    --LSTM_size=$LSTM_size \
    --LSTM_Layer_count=$LSTM_Layer_count \
    --conv_output=$conv_output \
    --conv_width=$conv_width \
    --dictionary="EN" \
    --training_directory=$training_directory \
    --curriculum_learning=False \
    --summary_name="dev" \
    --max_gpu_memory_use=0.2 \
    &

wait
