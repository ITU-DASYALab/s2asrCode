#!/bin/bash

#SBATCH -J Standard
#SBATCH -o ./logs/Standard-%A-%a-%N.out
#SBATCH -N 1
#SBATCH -t 6:00:00
#SBATCH --array=0-19%1
#SBATCH -c 48
#SBATCH -p gpu
#SBATCH --gres=gpu:v100:2
#SBATCH --mem=190000M



model="StreamSpeechM33"

training_directory="models/Standard-v2/"

FE_folder="FE_Chars"

input_tfrecord="FE_data/EN/$FE_folder/train*.tfrecord"
input_tfrecord_eval1="FE_data/EN/$FE_folder/train0000*.tfrecord"
input_tfrecord_eval2="FE_data/EN/$FE_folder/dev*.tfrecord"

dictionary="EN_chars"

if (( SLURM_ARRAY_TASK_ID > 0 )); then
    new_model=False
else
    new_model=True
fi

echo $new_model

python3 src/AM.py \
    --num_gpu=2 \
    --batch_size=160 \
    --input_tfrecord=$input_tfrecord \
    --dictionary=$dictionary \
    --training_directory=$training_directory \
    --buffer_size=100 \
    --curriculum_learning=False \
    --num_parallel_reader=16 \
    --model=$model \
    --new_model=$new_model \
    --include_unknown=False \
    &

sleep 60

python3 src/AM_eval.py \
    --batch_size=160 \
    --num_gpu=2 \
    --input_tfrecord=$input_tfrecord_eval1 \
    --dictionary=$dictionary \
    --training_directory=$training_directory \
    --summary_name="subset_data" \
    --curriculum_learning=False \
    --model=$model \
    --include_unknown=False \
    &
    
python3 src/AM_eval.py \
    --batch_size=160 \
    --num_gpu=2 \
    --input_tfrecord=$input_tfrecord_eval2 \
    --dictionary=$dictionary \
    --training_directory=$training_directory \
    --summary_name="dev_data" \
    --curriculum_learning=False \
    --model=$model \
    --include_unknown=False \
    &

wait
