#!/bin/bash

#SBATCH -J interleave
#SBATCH -o ./logs/interleave-%J-%N.out
#SBATCH -N 1
#SBATCH -t 24:00:00
#SBATCH -c 8
#SBATCH -p desktop
#SBATCH --gres=gpu:1
#SBATCH --mem=30000M


echo "Running on: $(hostname)"

name=$SLURM_JOB_NAME-$SLURM_JOB_ID-epocs$num_epochs
training_directory="models/interleave/$name/"
batch_size=80
LSTM_size=512
LSTM_Layer_count=2
conv_output=800
conv_width=5
max_frames=400 
FE_folder="FE_Chars"
input_tfrecord="FE_data/EN/$FE_folder/train*.tfrecord"
input_tfrecord_eval2="FE_data/EN/$FE_folder/dev*.tfrecord"
dictionary="EN_chars"

model="LogisticModel"

if [[ -z "$1" ]]; then
    num_epochs=50
else
    num_epochs=$1
fi

new_model=True


params="--num_gpu=0 \
    --batch_size=$batch_size \
    --input_tfrecord=$input_tfrecord \
    --LSTM_size=$LSTM_size \
    --LSTM_Layer_count=$LSTM_Layer_count \
    --conv_output=$conv_output \
    --conv_width=$conv_width \
    --dictionary=$dictionary \
    --curriculum_learning=False \
    --include_unknown=False \
    --max_frames=$max_frames \
    --model=$model "


while true; do 

python3 src/AM.py \
    --training_directory=$training_directory \
    --max_gpu_memory_use=0.6 \
    --buffer_size=100 \
    --num_epochs=$num_epochs \
    --new_model=$new_model \
    $params \

python3 src/AM_eval.py \
    --training_directory=$training_directory \
    --summary_name="dev" \
    --max_gpu_memory_use=0.2 \
    --wait_for_checkpoint=False \
    $params \

new_model=False

done
