#/bin/bash

model="LogisticModel"

new_model=True

python3 src/AM.py \
    --batch_size=64 \
    --num_gpu=4 \
    --LSTM_size=256 \
    --conv_output=512 \
    --conv_width=11 \
    --max_frames=1000 \
    --LSTM_Layer_count=1 \
    --model=$model \
    --eval_steps=10 \
    --save_model_interval=10 \
    --beam_width=32 \
    --curriculum_learning=False \
    --steps_until_max_frames=1000 \
    --dropout=0.05 \
    --input_tfrecord="FE_data/LibriSpeech/train00001.tfrecord" \
    --dictionary="EN_chars" \
    --include_unknown=False \
    --new_model=$new_model \
    --custom_beam_search=True \
    #--activation_function="relu6" \
