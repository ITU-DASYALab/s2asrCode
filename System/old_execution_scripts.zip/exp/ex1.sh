#/bin/bash

# Throttle alot, most likely because of transfereing the data to the three slow connection GPUs.
# This is also evident in the Volatile GPU Util that is almost always 0% on GPU 0 while 100% on 1,2,3
#python3 src/AM.py --num_gpu=4 --batch_size=2048 --training_directory="models/ex1/"


python3 src/AM.py --num_gpu=4 --batch_size=1024 --training_directory="models/ex1/"
