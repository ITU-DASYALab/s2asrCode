#/bin/bash


name="ex6-13"


#python3 src/AM.py \
#    --activate_learning_rate_decay=False \
#    --num_gpu=4 \
#    --batch_size=512 \
#    --training_directory="models/$name/" \
#    --input_tfrecord="FE_data/EN/train*.tfrecord" \
#    --dictionary="dict/EN.txt" \
#    &> graphs/ex3.out &


python3 src/AM.py \
    --activate_learning_rate_decay=False \
    --num_gpu=4 \
    --batch_size=64 \
    --base_learning_rate=1.0 \
    --max_frames=800 \
    --linear_scaling_rule=False \
    --save_model_interval=5 \
    --training_directory="models/$name/" \
    --input_tfrecord="FE_data/EN/train00001.tfrecord" \
    --dictionary="EN" \
    --regularization_penalty=0.8 \
    --l2_batch_normalization=False \
    --dropout=0 \
    --add_batch_norm=False \
    &> graphs/ex3.out &
    #--add_batch_norm=False


sleep 160

python3 src/AM_eval.py \
    --training_directory="models/$name/" \
    --input_tfrecord="FE_data/EN/train00001.tfrecord" \
    --dictionary="EN" \
    --summary_name="train_eval" \
    --batch_size=64 \
    --max_frames=800 \
    &> graphs/ex3_train_eval.out &
    #--add_batch_norm=False \

python3 src/AM_eval.py \
    --training_directory="models/$name/" \
    --input_tfrecord="FE_data/EN/train00001.tfrecord" \
    --dictionary="EN" \
    --summary_name="train_eval_drop_rem" \
    --batch_size=64 \
    --max_frames=800 \
    --drop_remainder=True \
    &> graphs/ex3_train_eval.out &
    #--add_batch_norm=False \
    
wait